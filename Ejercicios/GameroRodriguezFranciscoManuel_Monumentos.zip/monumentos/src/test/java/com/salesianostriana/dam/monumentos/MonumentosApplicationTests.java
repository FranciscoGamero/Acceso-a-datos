package com.salesianostriana.dam.monumentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonumentosApplicationTests {

    @Test
    void contextLoads() {
    }

}
